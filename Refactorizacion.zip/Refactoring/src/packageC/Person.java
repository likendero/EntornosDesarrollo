/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package packageC;

import java.util.Date;

/**
 *
 * @author profesor
 */
public class Person {
   public String firstName;
   public String lastName;
   public int numberOfNames = 0;
   public String address;
   public String username;
   public Date birthday;
   public double height;
   public double weight;
   public String eyecolor;
   public boolean married;
}
