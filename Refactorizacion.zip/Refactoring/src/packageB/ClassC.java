package packageB;

public class ClassC {

    public void method() {
        double d = 3.3;
        System.out.println(3.3);
        d = 3.3 + 3.3;
    }
}
