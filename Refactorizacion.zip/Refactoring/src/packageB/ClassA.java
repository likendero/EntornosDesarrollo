package packageB;

import java.util.LinkedList;
import java.util.List;

public class ClassA {

    public void method() {
        int x = 3 + 3;
        int y = 3 + 3 + 3;
        System.out.println(3 + 3);
    }

    public void method2() {
        int x = 3 + 3;
    }

    String constExpr = "CONST";

    public static void method3() {
        String s = "Text";
    }
    
    String konst = "a";
}
